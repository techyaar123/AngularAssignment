import { Component, OnInit } from '@angular/core';
import appointmentdata from "../../assets/appointmentlist.json";
import { PlaceAppointmentComponent }  from '../place-appointment/place-appointment.component';

@Component({
  selector: 'app-view-appointment',
  templateUrl: './view-appointment.component.html',
  styleUrls: ['./view-appointment.component.css']
})
// interface appointment{
//   sno:Number;
//     name:String;
//     age:Number;
//     email:String;
//     mobile:Number;
//     address1:String;
//     address2:String;
//     city:String;
//     state:String;
//     country:String;
//     pincode:Number;
//     trainer:String;
//     physio:String;
//     paln:String;
//     weeks:Number;
//     amount:Number;
// }
export class ViewAppointmentComponent  {
name:string='Abhinav';
  data!: PlaceAppointmentComponent;

 appoint:any=[
  {
    sno:1,
    name:"Abhinav",
    age:31,
    email:'abc@gmail.com',
    mobile:3123123123,
    address1:'randi',
    address2:'kala',
    city:'Bangalore',
    state:'Karnataka',
    country:'India',
    pincode:3423423,
    trainer:'Male',
    physio:'No',
    paln:'One session',
    weeks:0,
    amount:500
  },
  
  {
    sno:2,
    name:"Katiyar",
    age:33,
    email:'abc@gmail.com',
    mobile:3123123123,
    address1:'block no-104',
    address2:'Adityapur-1',
    city:'Jamshedpur',
    state:'Jharkhand',
    country:'India',
    pincode:3423423,
    trainer:'Female',
    physio:'Yes',
    paln:'4 session per week',
    weeks:2,
    amount:1000
  },
  {
    sno:3,
    name:"Abhi",
    age:31,
    email:'abc@gmail.com',
    mobile:3123123123,
    address1:'kala',
    address2:'pani',
    city:'mumbai',
    state:'Maharashtra',
    country:'India',
    pincode:3423423,
    trainer:'Female',
    physio:'No',
    paln:'5 week per session',
    weeks:1,
    amount:300
  },
  {
    sno:4,
    name:"Ram",
    age:28,
    email:'abc@gmail.com',
    mobile:3123123123,
    address1:'Sita',
    address2:'Raman',
    city:'Lanka',
    state:'Tamil Nadu',
    country:'India',
    pincode:3423423,
    trainer:'Male',
    physio:'No',
    paln:'5 week per session',
    weeks:2,
    amount:600
  },
  {
    sno:5,
    name:"Sita",
    age:22,
    email:'sita@gmail.com',
    mobile:3123123123,
    address1:'S ranchi Jharkhand India',
    address2:'ranchi',
    city:'Ranchi',
    state:'Jharkhand',
    country:'India',
    pincode:3423423,
    trainer:'Female',
    physio:'No',
    paln:'5 week per session',
    weeks:3,
    amount:900
  }
];
getList(){
  return this.appoint;
}
}
